"""
Ejercicio 6
Colocar en el fondo de la cola el primer nombre que inicie con la
letra 'A'.
"""

from queue_structure import Queue, mostrar_cola


def nombre_a_al_fondo(cola: Queue) -> None:
    """Busca el primer nombre que inicie con 'A' (mayúscula o
    minúscula) y lo coloca al fondo de la cola, conservando el orden
    relativo del resto."""
    # si está vacía no hay nada que hacer   
    if cola.is_empty():
        return

    n = cola.size()
    temporal = Queue()   # acá van todos los nombres menos el buscado
    encontrado = None    # acá guardo el nombre con "A" apenas lo encuentro

    # recorro toda la cola una sola vez
    for _ in range(n):
        valor = cola.dequeue()

        # con upper() no importa si es mayúscula o minúscula
        # y con "encontrado is None" me aseguro de agarrar solo el primero
        if encontrado is None and str(valor).upper().startswith("A"):
            encontrado = valor
        else:
            temporal.enqueue(valor)
 
    # devuelvo a "cola" todos los que NO eran el buscado, en su mismo orden
    while not temporal.is_empty():
        cola.enqueue(temporal.dequeue())

    # recién ahora agrego el encontrado, así queda al final (al fondo)
    if encontrado is not None:
        cola.enqueue(encontrado)


if __name__ == "__main__":
    # armo la cola de prueba
    cola = Queue()
    for nombre in ["Carlos", "Maria", "Andrea", "Pedro", "Ana"]:
        cola.enqueue(nombre)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que busca el primer nombre con "A" y lo manda al fondo
    nombre_a_al_fondo(cola)

    print("\nCola después ('Andrea' debe quedar al fondo):")
    mostrar_cola(cola)
