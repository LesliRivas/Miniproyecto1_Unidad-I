"""
Ejercicio 8
Escribir un algoritmo que saque de la cola todos los elementos ceros,
sin modificar la cola original.

Interpretación: se extraen (identifican y muestran) los ceros
presentes en la cola, pero al finalizar la cola original debe quedar
intacta, en el mismo orden.
"""

from queue_structure import Queue, mostrar_cola


def extraer_ceros(cola: Queue) -> Queue:
    """Recorre la cola identificando los elementos iguales a 0,
    devuelve una cola nueva con esos ceros y restaura la cola
    original sin modificarla."""
    n = cola.size()
    temporal = Queue()   # acá guardo TODOS los valores, para reconstruir la cola después
    ceros = Queue()      # acá guardo solo los ceros que voy encontrando

    # recorro la cola completa una sola vez
    for _ in range(n):
        valor = cola.dequeue()
        if valor == 0:
            ceros.enqueue(valor)  # si es cero, lo aparto también acá
        temporal.enqueue(valor)   # pase lo que pase, lo guardo para no perderlo

    # Restauramos la cola original en su orden inicial
    while not temporal.is_empty():
        cola.enqueue(temporal.dequeue())

    # devuelvo la cola con los ceros encontrados (por separado)
    return ceros


if __name__ == "__main__":
    # armo la cola de prueba, con varios ceros mezclados
    cola = Queue()
    for numero in [0, 5, 0, 3, 0, 8, 2]:
        cola.enqueue(numero)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que extrae los ceros sin tocar la cola original
    ceros = extraer_ceros(cola)

    print("\nCeros encontrados:")
    mostrar_cola(ceros)

    print("\nCola después (debe ser igual a la original):")
    mostrar_cola(cola)
