"""
queue_structure.py

Implementación del TDA (Tipo de Dato Abstracto) Cola (Queue) utilizando
collections.deque, siguiendo el principio FIFO (First In, First Out).


"""

from collections import deque
from typing import Any


class Queue:
    """
    Implementación del TDA Cola utilizando collections.deque.
    Garantiza complejidad temporal O(1) para encolar y desencolar.

    Todas las operaciones sobre la cola deben realizarse a través de los
    métodos públicos de esta clase (enqueue, dequeue, front, is_empty,
    size). No se debe acceder directamente al atributo interno _items.
    """

    def __init__(self) -> None:
        # Estructura interna: una instancia de deque
        self._items: deque = deque()

    def enqueue(self, item: Any) -> None:
        """Agrega un elemento al final de la cola. O(1)."""
        self._items.append(item)

    def dequeue(self) -> Any:
        """
        Elimina y retorna el elemento del frente de la cola. O(1).
        Lanza IndexError si la cola está vacía.
        """
        if self.is_empty():
            raise IndexError("dequeue(): la cola se encuentra vacía.")
        return self._items.popleft()

    def front(self) -> Any:
        """
        Retorna el elemento del frente sin eliminarlo. O(1).
        Lanza IndexError si la cola está vacía.
        """
        if self.is_empty():
            raise IndexError("front(): la cola se encuentra vacía.")
        return self._items[0]

    def is_empty(self) -> bool:
        """Verifica si la cola está vacía. O(1)."""
        return len(self._items) == 0

    def size(self) -> int:
        """Retorna el número de elementos presentes en la cola. O(1)."""
        return len(self._items)

    def __len__(self) -> int:
        """Permite usar la función integrada len(cola)."""
        return self.size()

    def __str__(self) -> str:
        """Representación en cadena mostrando el contenido de la cola,
        del frente hacia el fondo."""
        return f"Queue({list(self._items)})"

    def __repr__(self) -> str:
        return self.__str__()


def mostrar_cola(cola: "Queue") -> None:
    """
    Función auxiliar de conveniencia para imprimir el contenido de una
    cola sin modificarla, usando solo métodos públicos de Queue.
    """
    if cola.is_empty():
        print("Cola vacía: []")
        return

    temporal = Queue()
    elementos = []
    n = cola.size()
    for _ in range(n):
        valor = cola.dequeue()
        elementos.append(valor)
        temporal.enqueue(valor)

    # Restauramos la cola original
    while not temporal.is_empty():
        cola.enqueue(temporal.dequeue())

    print(f"Cola (frente -> fondo): {elementos}")


if __name__ == "__main__":
    # Pequeña demostración de la clase Queue
    cola_demo = Queue()
    cola_demo.enqueue(10)
    cola_demo.enqueue(20)
    cola_demo.enqueue(30)
    mostrar_cola(cola_demo)
    print("Frente:", cola_demo.front())
    print("Tamaño:", cola_demo.size())
    cola_demo.dequeue()
    mostrar_cola(cola_demo)
