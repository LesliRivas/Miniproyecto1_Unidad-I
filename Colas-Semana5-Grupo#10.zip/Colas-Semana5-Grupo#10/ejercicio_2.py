"""
Ejercicio 2
Imprimir la cantidad de elementos de la cola.
"""

from queue_structure import Queue, mostrar_cola


def imprimir_cantidad(cola: Queue) -> None:
    """Imprime la cantidad de elementos presentes en la cola."""

    # uso .size() para saber cuántos elementos hay, sin tocar la cola
    print("Cantidad de elementos en la cola:", cola.size())


if __name__ == "__main__":
    cola = Queue()

    # creo la cola y la cargo con algunos números
    for numero in [7, 19, 3, 56]:
        cola.enqueue(numero)

    
    # muestro cómo está la cola antes de contar
    print("Estado inicial de la cola:")
    mostrar_cola(cola)


    # llamo a la función que me dice cuántos elementos tiene
    imprimir_cantidad(cola)


    # ahora pruebo el caso borde: una cola vacía
    cola_vacia = Queue()
    print("\nPrueba con cola vacía:")
    imprimir_cantidad(cola_vacia) # debería mostrar 0