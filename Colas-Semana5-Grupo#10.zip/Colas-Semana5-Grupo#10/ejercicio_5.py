"""
Ejercicio 5
Colocar en la cima (frente) de la cola el primer nombre que inicie
con la letra 'A'.
"""

from queue_structure import Queue, mostrar_cola


def nombre_a_a_la_cima(cola: Queue) -> None:
    """Busca el primer nombre que inicie con 'A' (mayúscula o
    minúscula) y lo coloca en el frente de la cola, conservando el
    orden relativo del resto."""

    # si está vacía, no hay nada que buscar ni mover 
    if cola.is_empty():
        return

    n = cola.size()
    temporal = Queue()   # acá guardo todo lo que NO es el nombre buscado
    encontrado = None  # acá guardo el nombre que empieza con "A", si aparece 

    # recorro toda la cola una sola vez
    for _ in range(n):
        valor = cola.dequeue()
        # uso upper() para que no importe si es mayúscula o minúscula
        # y solo guardo el PRIMERO que cumpla (por eso pregunto "encontrado is None")
        if encontrado is None and str(valor).upper().startswith("A"):
            encontrado = valor
        else:
            temporal.enqueue(valor)    # el resto lo mando aparte, en orden

    # armo la cola final: primero el encontrado (si hay), después el resto
    resultado = Queue()
    if encontrado is not None:
        resultado.enqueue(encontrado)

    while not temporal.is_empty():
        resultado.enqueue(temporal.dequeue())

    # paso todo a "cola" para dejarla lista con el orden final
    while not resultado.is_empty():
        cola.enqueue(resultado.dequeue())


if __name__ == "__main__":
    # armo la cola de prueba con nombres
    cola = Queue()
    for nombre in ["Carlos", "Maria", "Andrea", "Pedro", "Ana"]:
        cola.enqueue(nombre)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que busca el primer nombre con "A" y lo pone al frente
    nombre_a_a_la_cima(cola)

    print("\nCola después ('Andrea' debe quedar en el frente):")
    mostrar_cola(cola)
