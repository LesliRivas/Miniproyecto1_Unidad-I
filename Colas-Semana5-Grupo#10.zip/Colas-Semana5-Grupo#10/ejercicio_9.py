"""
Ejercicio 9
Asumir la existencia de una cola de enteros y crear una cola temporal
con las raíces cuadradas de todos los valores contenidos en la cola,
sin modificar la cola original.
"""

import math

from queue_structure import Queue, mostrar_cola


def cola_de_raices(cola: Queue) -> Queue:
    """Genera una nueva cola con la raíz cuadrada de cada elemento de
    la cola original, dejando la cola original intacta."""
    n = cola.size()
    temporal = Queue()   # lo guardo tal cual, para no perder el original
    raices = Queue()      # calculo la raíz cuadrada

    # recorro toda la cola una sola vez
    for _ in range(n):
        valor = cola.dequeue()
        temporal.enqueue(valor)
        raiz = math.sqrt(valor)

        # Si la raíz es un número entero exacto (ej. 2.0), lo mostramos
        # como entero (2) en vez de decimal.
        if raiz == int(raiz):
            raiz = int(raiz)

        raices.enqueue(raiz)

    # Restauramos la cola original
    while not temporal.is_empty():
        cola.enqueue(temporal.dequeue())

    return raices


if __name__ == "__main__":
    cola = Queue()
    for numero in [4, 9, 16, 25]:
        cola.enqueue(numero)

    print("Cola original:")
    mostrar_cola(cola)

    # ejecuto la función que arma la cola de raíces, sin tocar la original
    raices = cola_de_raices(cola)

    print("\nCola de raíces cuadradas:")
    mostrar_cola(raices)

    print("\nCola original después (debe quedar igual):")
    mostrar_cola(cola)