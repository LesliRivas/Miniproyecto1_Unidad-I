"""
Ejercicio 1
Imprimir el primer elemento de la cola sin modificarla.
"""

from queue_structure import Queue, mostrar_cola


def imprimir_frente(cola: Queue) -> None:
    """Imprime el elemento del frente de la cola sin modificarla."""

    # primero me fijo si la cola está vacía, porque si no hay nada, no tengo qué mostrar
    if cola.is_empty():
        print("La cola está vacía, no hay frente que mostrar.")
        return

    # uso .front() porque solo quiero ver el primer elemento, no sacarlo de la cola
    print("Elemento en el frente de la cola:", cola.front())


if __name__ == "__main__":

    # creo una cola nueva vacía
    cola = Queue()

    # cargo varios números en la cola, uno por uno, con enqueue
    for numero in [15, 8, 23, 4, 42]:
        cola.enqueue(numero)

    # muestro cómo quedó la cola antes de hacer nada   
    print("Estado inicial de la cola:")
    mostrar_cola(cola)

    # llamo a mi función para ver el frente sin tocar la cola
    imprimir_frente(cola)

    # vuelvo a mostrar la cola para comprobar que no cambió en nada
    print("\nEstado de la cola después de la operación (debe ser igual):")
    mostrar_cola(cola)

    # ahora pruebo el caso borde: una cola vacía
    cola_vacia = Queue()
    print("\nPrueba con cola vacía:")
    imprimir_frente(cola_vacia)       # esto debería mostrar el mensaje de "vacía"
