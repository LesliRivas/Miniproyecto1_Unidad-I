"""
Ejercicio 3
Colocar en el fondo de la cola el número mayor de la cola.

Estrategia: recorremos la cola usando solo dequeue()/enqueue() para
encontrar el valor mayor y reconstruirla en el mismo orden, pero
dejando fuera la primera aparición del mayor para agregarla al final.
"""

from queue_structure import Queue, mostrar_cola


def mayor_al_fondo(cola: Queue) -> None:
    """Mueve el número mayor de la cola hacia el fondo, conservando
    el orden relativo del resto de los elementos."""

    # si está vacía no hay nada que mover
    if cola.is_empty():
        return

    n = cola.size()  # guardo el tamaño original para saber cuántas vueltas dar
    mayor = cola.front()  # arranco suponiendo que el mayor es el primero


    # primera pasada: saco todo de "cola" y lo voy pasando a "temporal",
    # de paso voy comparando para encontrar el valor mayor real
    temporal = Queue()
    for _ in range(n):
        valor = cola.dequeue()
        if valor > mayor:
            mayor = valor
        temporal.enqueue(valor)
    # en este punto "cola" quedó vacía y "temporal" tiene el mismo orden original


    # segunda pasada: paso todo de "temporal" de vuelta a "cola",
    # pero salteo la primera vez que aparece el mayor (esa la agrego al final)
    encontrado = False
    n2 = temporal.size()
    for _ in range(n2):
        valor = temporal.dequeue()
        if not encontrado and valor == mayor:
            encontrado = True
            continue   # no lo meto ahora, lo voy a agregar al final
        cola.enqueue(valor)

    # recién acá agrego el mayor, así queda al fondo de la cola
    cola.enqueue(mayor)


if __name__ == "__main__":
    # armo la cola de prueba
    cola = Queue()
    for numero in [12, 45, 3,  9, 1]:
        cola.enqueue(numero)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que mueve el mayor al fondo
    mayor_al_fondo(cola)

    print("\nCola después (el mayor debe quedar al fondo):")
    mostrar_cola(cola)
