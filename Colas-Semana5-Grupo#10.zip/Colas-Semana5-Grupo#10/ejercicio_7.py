"""
Ejercicio 7
Escribir un algoritmo que invierta los elementos de una cola.

Estrategia: usamos una lista auxiliar como apoyo. Sacamos todos los
elementos de la cola con dequeue() y los guardamos en una lista;
luego los volvemos a meter con enqueue() en orden contrario (usando
pop(), que siempre saca el último elemento de la lista), usando
únicamente los métodos públicos de Queue.
"""

from queue_structure import Queue, mostrar_cola


def invertir_cola(cola: Queue) -> None:
    """Invierte el orden de los elementos de la cola, modificándola
    directamente."""
    auxiliar = []   # lista normal de Python, la uso como apoyo

    # saco todo de la cola y lo voy guardando en la lista, en el mismo orden
    while not cola.is_empty():
        auxiliar.append(cola.dequeue())

    # Los volvemos a meter en orden contrario (pop() saca el último)
    while auxiliar:
        cola.enqueue(auxiliar.pop())


if __name__ == "__main__":
    # armo la cola de prueba
    cola = Queue()
    for numero in [1, 2, 3, 4, 5]:
        cola.enqueue(numero)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que invierte el orden de la cola
    invertir_cola(cola)

    print("\nCola después (invertida):")
    mostrar_cola(cola)