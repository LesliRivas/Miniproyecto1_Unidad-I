"""
Ejercicio 4
Colocar en la cima (frente) de la cola el número menor de la cola.

Estrategia: encontramos el menor recorriendo la cola con dequeue()/
enqueue(), luego reconstruimos una nueva cola colocando primero el
menor y después el resto de los elementos en su orden original.
"""

from queue_structure import Queue, mostrar_cola


def menor_a_la_cima(cola: Queue) -> None:
    """Mueve el número menor de la cola hacia el frente, conservando
    el orden relativo del resto de los elementos."""

    # si no hay elementos, no hay nada que reordenar
    if cola.is_empty():
        return

    n = cola.size()  # tamaño original para controlar el recorrido
    menor = cola.front()  # arranco suponiendo que el menor es el primero


    # primera pasada: vacío "cola" y voy pasando todo a "temporal",
    # aprovechando para encontrar cuál es el valor menor real
    temporal = Queue()
    for _ in range(n):
        valor = cola.dequeue()
        if valor < menor:
            menor = valor
        temporal.enqueue(valor)
    # acá "cola" quedó vacía y "temporal" tiene el orden original completo


    # armo una cola nueva para el resultado, empezando por el menor
    # (así queda garantizado que va a estar al frente)
    resultado = Queue()
    resultado.enqueue(menor)

    # ahora recorro "temporal" y voy agregando todo a "resultado",
    # salvo la primera aparición del menor, que ya se agregó arriba
    encontrado = False
    n2 = temporal.size()
    for _ in range(n2):
        valor = temporal.dequeue()
        if not encontrado and valor == menor:
            encontrado = True
            continue  # ya se agregó al frente
        resultado.enqueue(valor)

    # paso todo de "resultado" a "cola", así "cola" queda con el orden final
    while not resultado.is_empty():
        cola.enqueue(resultado.dequeue())


if __name__ == "__main__":
    # armo la cola de prueba
    cola = Queue()
    for numero in [12, 45, 3, 9, 1]:
        cola.enqueue(numero)

    print("Cola antes:")
    mostrar_cola(cola)

    # ejecuto la función que lleva el menor al frente
    menor_a_la_cima(cola)

    print("\nCola después (el menor debe quedar en el frente):")
    mostrar_cola(cola)
